package com.example.qrhayot.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.qrhayot.R
import com.example.qrhayot.data.Profile
import com.example.qrhayot.t
import com.example.qrhayot.ui.components.*
import com.example.qrhayot.ui.theme.*
import com.example.qrhayot.util.*

@Composable
fun QrScreen(profile: Profile, onBack: () -> Unit) {
    val context = LocalContext.current
    val text = buildQrText(profile)
    val qr = remember(text) { makeQr(text) }
    var askLock by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TopBar(t("Mening QR kodim", "My QR code"), onBack)
        Text(
            t("Qulf ekraniga, sumkaga yoki hamyonga qo'ying. Kimdir skaner qilsa, sizga qanday yordam berishni ko'radi.", "Put it on your lock screen, bag or wallet. Anyone who scans it will see how to help you."),
            style = MaterialTheme.typography.bodyMedium,
            color = TextGrey
        )

        if (qr == null) {
            Text(t("Matn juda uzun. Ko'rsatmalarni qisqartiring.", "The text is too long. Make the instructions shorter."), style = MaterialTheme.typography.bodyMedium, color = PinkDark)
        } else {

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Blue)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(White)
                        .padding(14.dp)
                ) {
                    Image(qr.asImageBitmap(), contentDescription = t("Favqulodda QR kod", "Emergency QR code"), modifier = Modifier.size(230.dp))
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_qr), contentDescription = null, tint = Teal, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(t("Oddiy telefon kamerasi bilan o'qiladi", "Any phone camera can read it"), style = MaterialTheme.typography.labelMedium, color = Teal)
                }
            }

            if (text.toByteArray().size > 900) {
                Text(
                    t("Matn uzun, QR kod zich bo'lib qoldi. Kichik stikerda qiyin o'qilishi mumkin.", "The text is long, so the QR is dense. It may be hard to scan on a small sticker."),
                    style = MaterialTheme.typography.bodySmall,
                    color = PinkDark
                )
            }

            MainButton(t("Qulf ekraniga qo'yish", "Set as lock screen"), R.drawable.ic_lock, onClick = { askLock = true })
            LightButton(t("Rasm sifatida ulashish", "Share as picture"), R.drawable.ic_share, onClick = {
                shareImage(context, makePoster(qr, 1080, 1920))
            })
        }

        // Exactly what a stranger will see after scanning
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Lavender)
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(R.drawable.ic_info), contentDescription = null, tint = LavenderDark, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(t("Skaner qilgan odam ko'radi", "What a person sees after scanning"), style = MaterialTheme.typography.titleSmall, color = TextDark)
            }
            Spacer(Modifier.height(10.dp))
            Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp, color = TextDark)
        }
    }

    if (askLock) {
        AlertDialog(
            onDismissRequest = { askLock = false },
            containerColor = White,
            shape = RoundedCornerShape(24.dp),
            icon = { IconBubble(R.drawable.ic_lock, Teal, Blue, 52.dp) },
            title = { Text(t("Qulf ekraniga qo'yish", "Set as lock screen")) },
            text = { Text(t("Hozirgi qulf ekrani rasmingiz QR kod bilan almashtiriladi. Davom etasizmi?", "Your current lock screen picture will be replaced with the QR code. Continue?")) },
            confirmButton = {
                TextButton(onClick = {
                    askLock = false
                    if (qr != null) {
                        val screen = context.resources.displayMetrics
                        val ok = setLockScreen(context, makePoster(qr, screen.widthPixels, screen.heightPixels))
                        if (ok) {
                            Toast.makeText(context, t("Tayyor! Telefonni qulflab tekshiring.", "Done! Lock your phone to check."), Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, t("Bu telefon ruxsat bermadi. Rasmni ulashib, qo'lda qo'ying.", "This phone did not allow it. Share the picture and set it by hand."), Toast.LENGTH_LONG).show()
                        }
                    }
                }) {
                    Text(t("Ha, qo'yish", "Yes, set it"), color = Teal)
                }
            },
            dismissButton = {
                TextButton(onClick = { askLock = false }) {
                    Text(t("Bekor qilish", "Cancel"), color = TextGrey)
                }
            }
        )
    }
}
