package com.example.qrhayot.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key.Companion.LanguageSwitch
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension
import com.example.qrhayot.R
import com.example.qrhayot.data.Profile
import com.example.qrhayot.t
import com.example.qrhayot.ui.components.*
import com.example.qrhayot.ui.theme.*
import com.example.qrhayot.util.*

@Composable
fun HomeScreen(profile: Profile, onOpen: (String) -> Unit, onSos: () -> Unit) {
    val context = LocalContext.current

    var shownName = profile.name
    if (shownName.isBlank()) {
        shownName = t("Ismingizni kiriting", "Add your name")
    }

    var contactName = t("Kiritilmagan", "Not added")
    if (profile.contact1Phone.isNotBlank()) {
        contactName = profile.contact1Name
        if (contactName.isBlank()) {
            contactName = profile.contact1Phone
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t("Assalomu alaykum,", "Hello,"), style = MaterialTheme.typography.bodyMedium, color = TextGrey)
                Text(shownName, style = MaterialTheme.typography.headlineMedium, color = TextDark, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            LanguageSwitch()
            Spacer(Modifier.width(10.dp))
            Avatar(profile.name, onClick = { onOpen("personal") })
        }

        Spacer(Modifier.height(20.dp))


        ConstraintLayout(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Blue)
                .clickable { onOpen("qr") }
                .padding(20.dp)
        ) {
            val (title, text, button, picture) = createRefs()

            Image(
                painter = painterResource(R.drawable.ill_qr_phone),
                contentDescription = null,
                modifier = Modifier
                    .size(128.dp)
                    .constrainAs(picture) {
                        end.linkTo(parent.end)
                        top.linkTo(parent.top)
                        bottom.linkTo(parent.bottom)
                    }
            )
            Text(
                t("Favqulodda QR kodim", "My emergency QR"),
                style = MaterialTheme.typography.titleLarge,
                color = Teal,
                modifier = Modifier.constrainAs(title) {
                    top.linkTo(parent.top)
                    start.linkTo(parent.start)
                    end.linkTo(picture.start, 8.dp)
                    width = Dimension.fillToConstraints
                }
            )
            Text(
                t("Atrofdagilar skaner qilib, sizga qanday yordam berishni biladi.", "People nearby scan it and learn how to help you."),
                style = MaterialTheme.typography.bodySmall,
                color = TextGrey,
                modifier = Modifier.constrainAs(text) {
                    top.linkTo(title.bottom, 6.dp)
                    start.linkTo(parent.start)
                    end.linkTo(picture.start, 8.dp)
                    width = Dimension.fillToConstraints
                }
            )
            Button(
                onClick = { onOpen("qr") },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Teal),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                modifier = Modifier.constrainAs(button) {
                    top.linkTo(text.bottom, 14.dp)
                    start.linkTo(parent.start)
                }
            ) {
                Text(t("QR kodni ochish", "Open QR code"), style = MaterialTheme.typography.labelMedium)
            }
        }

        Spacer(Modifier.height(14.dp))


        SoftCard(color = Pink, onClick = onSos, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(R.drawable.ic_sos, PinkDark, White, 52.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(t("SOS xabar yuborish", "Send SOS message"), style = MaterialTheme.typography.titleMedium, color = PinkDark)
                    Text(t("Yaqinlarimga joylashuvim bilan SMS", "SMS with my location to my contacts"), style = MaterialTheme.typography.bodySmall, color = TextGrey)
                }
            }
        }


        SectionTitle(t("Ma'lumotlarim", "My information"))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Tile(R.drawable.ic_person, t("Shaxsiy", "Personal"), Blue, Teal, onClick = { onOpen("personal") })
            Tile(R.drawable.ic_medical, t("Tibbiy", "Medical"), Pink, PinkDark, onClick = { onOpen("medical") })
            Tile(R.drawable.ic_first_aid, t("Yordam", "First aid"), Mint, MintDark, onClick = { onOpen("firstaid") })
            Tile(R.drawable.ic_phone, t("Yaqinlar", "Contacts"), Peach, PeachDark, onClick = { onOpen("contacts") })
        }


        SectionTitle(t("Yordam asboblari", "Help tools"))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Tile(R.drawable.ic_timer, t("Taymer", "Timer"), Lavender, LavenderDark, onClick = { onOpen("timer") })
            Tile(R.drawable.ic_pulse, t("Yurak", "CPR"), Pink, PinkDark, onClick = { onOpen("cpr") })
            Tile(R.drawable.ic_siren, t("Sirena", "Siren"), Peach, PeachDark, onClick = { onOpen("siren") })
            Tile(R.drawable.ic_hospital, t("Shifoxona", "Hospital"), Mint, MintDark, onClick = { openMap(context, t("shifoxona", "hospital")) })
        }

        // ---------- Summary ----------
        SectionTitle(t("Qisqacha", "Summary"))

        SoftCard(color = Lavender, onClick = { onOpen("firstaid") }, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t("Holatim", "My condition"), style = MaterialTheme.typography.bodyMedium, color = TextGrey)
                    Spacer(Modifier.height(4.dp))
                    Text(showValue(profile.condition), style = MaterialTheme.typography.headlineSmall, color = TextDark)
                    Spacer(Modifier.height(4.dp))
                    Text(t("Birinchi yordam ko'rsatmasi", "First aid instructions"), style = MaterialTheme.typography.bodySmall, color = LavenderDark)
                }
                IconBubble(R.drawable.ic_heart, PinkDark, White, 64.dp)
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryCard(
                R.drawable.ic_drop, t("Qon guruhi", "Blood type"), showValue(profile.bloodType),
                Pink, PinkDark, Modifier.weight(1f), onClick = { onOpen("medical") }
            )
            // Tap to call the first contact
            SummaryCard(
                R.drawable.ic_phone, t("Qo'ng'iroq", "Call"), contactName,
                Mint, MintDark, Modifier.weight(1f), onClick = {
                    if (profile.contact1Phone.isNotBlank()) {
                        callNumber(context, profile.contact1Phone)
                    } else {
                        onOpen("contacts")
                    }
                }
            )
        }


        SectionTitle(t("Favqulodda raqamlar", "Emergency numbers"))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NumberCard(R.drawable.ic_cross, "103", t("Tez yordam", "Ambulance"), Pink, PinkDark, Modifier.weight(1f), onClick = { callNumber(context, "103") })
            NumberCard(R.drawable.ic_flame, "101", t("O't o'chirish", "Fire"), Peach, PeachDark, Modifier.weight(1f), onClick = { callNumber(context, "101") })
            NumberCard(R.drawable.ic_shield, "102", t("Militsiya", "Police"), Blue, Teal, Modifier.weight(1f), onClick = { callNumber(context, "102") })
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Avatar(name: String, onClick: () -> Unit) {
    var letter = "?"
    if (name.isNotBlank()) {
        letter = name.trim().substring(0, 1).uppercase()
    }
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(Blue)
            .border(3.dp, White, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(letter, style = MaterialTheme.typography.titleLarge, color = Teal)
    }
}

@Composable
fun Tile(icon: Int, label: String, color: Color, iconColor: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(74.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(color)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(icon), contentDescription = label, tint = iconColor, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = TextDark)
    }
}

@Composable
fun SummaryCard(icon: Int, title: String, value: String, color: Color, iconColor: Color, modifier: Modifier, onClick: () -> Unit) {
    SoftCard(color = color, onClick = onClick, modifier = modifier) {
        Column {
            Icon(painterResource(icon), contentDescription = null, tint = iconColor, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(14.dp))
            Text(title, style = MaterialTheme.typography.bodySmall, color = TextGrey)
            Text(value, style = MaterialTheme.typography.titleMedium, color = TextDark, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun NumberCard(icon: Int, number: String, label: String, color: Color, iconColor: Color, modifier: Modifier, onClick: () -> Unit) {
    SoftCard(color = color, onClick = onClick, modifier = modifier) {
        Column {
            IconBubble(icon, iconColor, White, 36.dp)
            Spacer(Modifier.height(10.dp))
            Text(number, style = MaterialTheme.typography.titleLarge, color = TextDark)
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextGrey, maxLines = 1)
        }
    }
}


@Preview(showBackground = true, backgroundColor = 0xFFF7F9FB, heightDp = 1250)
@Composable
fun HomePreview() {
    val p = Profile()
    p.name = "Aziza Karimova"
    p.bloodType = "A(II) Rh+"
    p.condition = "Epilepsiya"
    p.contact1Name = "Onam"
    p.contact1Phone = "+998901234567"
    QRHayotTheme {
        HomeScreen(p, onOpen = {}, onSos = {})
    }
}
