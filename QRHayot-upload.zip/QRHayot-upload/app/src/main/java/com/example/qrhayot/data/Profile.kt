package com.example.qrhayot.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Profile {
    var name by mutableStateOf("")
    var birthYear by mutableStateOf("")
    var languages by mutableStateOf("")
    var notes by mutableStateOf("")

    var bloodType by mutableStateOf("")
    var allergies by mutableStateOf("")
    var medicines by mutableStateOf("")
    var medicineLocation by mutableStateOf("")

    var condition by mutableStateOf("")
    var doSteps by mutableStateOf("")
    var dontSteps by mutableStateOf("")
    var myTips by mutableStateOf("")

    var contact1Name by mutableStateOf("")
    var contact1Phone by mutableStateOf("")
    var contact2Name by mutableStateOf("")
    var contact2Phone by mutableStateOf("")

    var updated by mutableStateOf("")
}

// Data is saved only on this phone.
fun loadProfile(context: Context): Profile {
    val prefs = context.getSharedPreferences("qr_hayot", Context.MODE_PRIVATE)
    val p = Profile()
    p.name = readText(prefs, "name")
    p.birthYear = readText(prefs, "birthYear")
    p.languages = readText(prefs, "languages")
    p.notes = readText(prefs, "notes")
    p.bloodType = readText(prefs, "bloodType")
    p.allergies = readText(prefs, "allergies")
    p.medicines = readText(prefs, "medicines")
    p.medicineLocation = readText(prefs, "medicineLocation")
    p.condition = readText(prefs, "condition")
    p.doSteps = readText(prefs, "doSteps")
    p.dontSteps = readText(prefs, "dontSteps")
    p.myTips = readText(prefs, "myTips")
    p.contact1Name = readText(prefs, "contact1Name")
    p.contact1Phone = readText(prefs, "contact1Phone")
    p.contact2Name = readText(prefs, "contact2Name")
    p.contact2Phone = readText(prefs, "contact2Phone")
    p.updated = readText(prefs, "updated")
    return p
}

fun saveProfile(context: Context, p: Profile) {
    val editor = context.getSharedPreferences("qr_hayot", Context.MODE_PRIVATE).edit()
    editor.putString("name", p.name)
    editor.putString("birthYear", p.birthYear)
    editor.putString("languages", p.languages)
    editor.putString("notes", p.notes)
    editor.putString("bloodType", p.bloodType)
    editor.putString("allergies", p.allergies)
    editor.putString("medicines", p.medicines)
    editor.putString("medicineLocation", p.medicineLocation)
    editor.putString("condition", p.condition)
    editor.putString("doSteps", p.doSteps)
    editor.putString("dontSteps", p.dontSteps)
    editor.putString("myTips", p.myTips)
    editor.putString("contact1Name", p.contact1Name)
    editor.putString("contact1Phone", p.contact1Phone)
    editor.putString("contact2Name", p.contact2Name)
    editor.putString("contact2Phone", p.contact2Phone)
    editor.putString("updated", p.updated)
    editor.apply()
}

fun readText(prefs: SharedPreferences, key: String): String {
    val value = prefs.getString(key, "")
    if (value == null) {
        return ""
    } else {
        return value
    }
}

// Today's date, for example "01.10.2026"
fun today(): String {
    return SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())
}
