package com.example.qrhayot.ui.theme

import androidx.compose.ui.graphics.Color

// Page and text
val Background = Color(0xFFF7F9FB)
val White = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1E2A33)
val TextGrey = Color(0xFF6B7780)
val Line = Color(0xFFE3E8EC)

// Soft pastel backgrounds + a darker partner color for icons and text on top of them
val Blue = Color(0xFFDDEFF6)
val Teal = Color(0xFF2E7D8C)

val Pink = Color(0xFFF9E3E6)
val PinkDark = Color(0xFFC0566A)

val Mint = Color(0xFFE3F4E4)
val MintDark = Color(0xFF3F8A5C)

val Peach = Color(0xFFFCEFDC)
val PeachDark = Color(0xFFC08A3E)

val Lavender = Color(0xFFEEE8F8)
val LavenderDark = Color(0xFF6E5BA8)
