package com.example.qrhayot

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.qrhayot.data.Profile
import com.example.qrhayot.data.saveProfile
import com.example.qrhayot.data.today
import com.example.qrhayot.ui.screens.*
import com.example.qrhayot.util.sendSos


@Composable
fun AppNavigation(profile: Profile) {
    val context = LocalContext.current
    val navController = rememberNavController()


    val open: (String) -> Unit = { route ->
        navController.navigate(route) {
            launchSingleTop = true
        }
    }

    val goBack: () -> Unit = {
        if (navController.previousBackStackEntry != null) {
            navController.popBackStack()
        }
    }


    val saveAndBack: () -> Unit = {
        profile.updated = today()
        saveProfile(context, profile)
        goBack()
    }


    val askLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        sendSos(context, profile)
    }
    val startSos: () -> Unit = {
        if (profile.contact1Phone.isBlank() && profile.contact2Phone.isBlank()) {
            Toast.makeText(context, t("Avval yaqinlaringiz raqamini kiriting", "First add your contacts' phone numbers"), Toast.LENGTH_LONG).show()
            open("contacts")
        } else {
            askLocation.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(profile, open, startSos) }


        composable("personal") { PersonalScreen(profile, saveAndBack) }
        composable("medical") { MedicalScreen(profile, saveAndBack) }
        composable("firstaid") { FirstAidScreen(profile, saveAndBack) }
        composable("contacts") { ContactsScreen(profile, saveAndBack) }


        composable("qr") { QrScreen(profile, goBack) }


        composable("timer") { TimerScreen(goBack) }
        composable("cpr") { CprScreen(goBack) }
        composable("siren") { SirenScreen(goBack) }
    }
}
