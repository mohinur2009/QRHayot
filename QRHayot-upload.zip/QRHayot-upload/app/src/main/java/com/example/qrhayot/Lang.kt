package com.example.qrhayot

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue


object Lang {
    var english by mutableStateOf(false)
}


fun t(uz: String, en: String): String {
    if (Lang.english) {
        return en
    } else {
        return uz
    }
}

fun loadLanguage(context: Context) {
    val prefs = context.getSharedPreferences("qr_hayot", Context.MODE_PRIVATE)
    Lang.english = prefs.getBoolean("english", false)
}

fun saveLanguage(context: Context) {
    val prefs = context.getSharedPreferences("qr_hayot", Context.MODE_PRIVATE)
    prefs.edit().putBoolean("english", Lang.english).apply()
}
