package com.example.qrhayot.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.qrhayot.R
import com.example.qrhayot.t
import com.example.qrhayot.ui.components.*
import com.example.qrhayot.ui.theme.*
import com.example.qrhayot.util.callNumber
import com.example.qrhayot.util.makeTone
import kotlinx.coroutines.delay


@Composable
fun TimerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var running by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(0) }


    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            seconds = seconds + 1
        }
    }

    val minutesText = (seconds / 60).toString().padStart(2, '0')
    val secondsText = (seconds % 60).toString().padStart(2, '0')

    var circleColor = Lavender
    var timeColor = LavenderDark
    if (seconds >= 300) {
        circleColor = Pink
        timeColor = PinkDark
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TopBar(t("Tutqanoq taymeri", "Seizure timer"), onBack)
        Text(
            t("Tutqanoq boshlanganda bosing. Vaqtni bilish eng muhim yordamdir.", "Press when the seizure starts. Knowing the time is the most important help."),
            style = MaterialTheme.typography.bodyMedium,
            color = TextGrey
        )


        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(circleColor),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(painterResource(R.drawable.ic_timer), contentDescription = null, tint = timeColor, modifier = Modifier.size(30.dp))
                    Text(minutesText + ":" + secondsText, style = MaterialTheme.typography.headlineMedium, fontSize = 52.sp, color = timeColor)
                }
            }
        }

        if (running) {
            MainButton(t("To'xtatish", "Stop"), R.drawable.ic_stop, onClick = { running = false })
        } else {
            MainButton(t("Boshlash", "Start"), R.drawable.ic_play, onClick = { running = true })
        }
        LightButton(t("Qaytadan", "Reset"), R.drawable.ic_reset, onClick = {
            running = false
            seconds = 0
        })


        if (seconds >= 300) {
            InfoBox(t("5 daqiqadan oshdi! Hoziroq 103 ga qo'ng'iroq qiling.", "Over 5 minutes! Call 103 now."), Pink, PinkDark)
            MainButton(t("103 ga qo'ng'iroq", "Call 103"), R.drawable.ic_phone, onClick = { callNumber(context, "103") })
        } else if (seconds >= 120) {
            InfoBox(t("Ko'p tutqanoqlar 2 daqiqa ichida to'xtaydi. Kuzatishda davom eting.", "Most seizures stop within 2 minutes. Keep watching."), Peach, PeachDark)
        } else {
            InfoBox(t("Boshi ostiga yumshoq narsa qo'ying. Og'ziga hech narsa solmang.", "Put something soft under the head. Put nothing in the mouth."), Mint, MintDark)
        }
        InfoBox(
            t(
                "Shuningdek 103 ga qo'ng'iroq qiling, agar:\n• bu birinchi tutqanoq bo'lsa\n• jarohat olgan bo'lsa\n• suvda sodir bo'lgan bo'lsa\n• o'ziga kelmasa yoki yana boshlansa",
                "Also call 103 if:\n• it is their first seizure\n• they are injured\n• it happened in water\n• they don't wake up or it starts again"
            ),
            Lavender,
            LavenderDark
        )
    }
}


@Composable
fun CprScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var running by remember { mutableStateOf(false) }
    var pushing by remember { mutableStateOf(false) }
    var count by remember { mutableStateOf(0) }

    LaunchedEffect(running) {
        if (running) {
            val tone = makeTone(AudioManager.STREAM_MUSIC)
            try {
                while (true) {
                    if (tone != null) {
                        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
                    }
                    pushing = true
                    count = count + 1
                    delay(150)
                    pushing = false
                    delay(395)   // 150 + 395 = 545 ms, that is 110 pushes per minute
                }
            } finally {
                if (tone != null) {
                    tone.release()
                }
            }
        }
    }


    var target = 170.dp
    var circleColor = Pink
    var iconColor = PinkDark
    if (pushing) {
        target = 205.dp
        circleColor = PinkDark
        iconColor = White
    }
    val circleSize by animateDpAsState(targetValue = target, label = "push")

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TopBar(t("Yurak massaji ritmi", "CPR rhythm"), onBack)
        InfoBox(
            t("Faqat hushsiz va normal nafas olmayotgan odam uchun.", "Only for someone who is unconscious and not breathing normally."),
            Pink,
            PinkDark
        )

        Box(
            Modifier
                .fillMaxWidth()
                .height(220.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(circleSize)
                    .clip(CircleShape)
                    .background(circleColor),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(painterResource(R.drawable.ic_pulse), contentDescription = null, tint = iconColor, modifier = Modifier.size(48.dp))
                    Text(t("BOSING", "PUSH"), style = MaterialTheme.typography.titleLarge, color = iconColor)
                }
            }
        }

        Text(
            t("Bosishlar: ", "Pushes: ") + count + "   •   " + t("daqiqasiga 110 marta", "110 per minute"),
            style = MaterialTheme.typography.titleSmall,
            color = TextDark,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        if (running) {
            MainButton(t("To'xtatish", "Stop"), R.drawable.ic_stop, onClick = { running = false })
        } else {
            MainButton(t("Ritmni boshlash", "Start rhythm"), R.drawable.ic_play, onClick = {
                count = 0
                running = true
            })
        }
        LightButton(t("103 ga qo'ng'iroq", "Call 103"), R.drawable.ic_phone, onClick = { callNumber(context, "103") })

        InfoBox(
            t(
                "1. 103 ga qo'ng'iroq qiling yoki boshqa odamdan so'rang.\n2. Kaftlarni ko'krak qafasi o'rtasiga qo'ying.\n3. Har bir ovozda qattiq bosing: 5-6 sm chuqurlikda.\n4. Tez yordam kelguncha to'xtamang.",
                "1. Call 103 or ask someone else to.\n2. Put your hands in the center of the chest.\n3. Push hard on every beep: 5-6 cm deep.\n4. Don't stop until the ambulance arrives."
            ),
            Lavender,
            LavenderDark
        )
    }
}


@Composable
fun SirenScreen(onBack: () -> Unit) {
    var on by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf(false) }

    LaunchedEffect(on) {
        if (on) {
            val tone = makeTone(AudioManager.STREAM_ALARM)
            try {
                while (true) {
                    if (tone != null) {
                        tone.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 450)
                    }
                    flash = true
                    delay(500)
                    if (tone != null) {
                        tone.startTone(ToneGenerator.TONE_CDMA_LOW_L, 450)
                    }
                    flash = false
                    delay(500)
                }
            } finally {
                if (tone != null) {
                    tone.release()
                }
                flash = false
            }
        }
    }

    var pageColor = Background
    if (flash) {
        pageColor = Pink
    }
    var buttonColor = White
    var iconColor = PinkDark
    var buttonText = t("Yoqish", "Turn on")
    if (on) {
        buttonColor = PinkDark
        iconColor = White
        buttonText = t("O'chirish", "Turn off")
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(pageColor)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TopBar(t("Sirena", "Siren"), onBack)
        Text(
            t("Atrofdagilarning e'tiborini tortish uchun baland ovoz va miltillovchi ekran.", "A loud sound and a flashing screen to get people's attention."),
            style = MaterialTheme.typography.bodyMedium,
            color = TextGrey
        )

        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(230.dp)
                    .clip(CircleShape)
                    .background(buttonColor)
                    .border(2.dp, Pink, CircleShape)
                    .clickable { on = !on },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(painterResource(R.drawable.ic_siren), contentDescription = null, tint = iconColor, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(buttonText, style = MaterialTheme.typography.titleLarge, color = iconColor)
                }
            }
        }

        InfoBox(
            t("Telefonning budilnik ovozi baland ekanini tekshiring.", "Make sure your phone's alarm volume is up."),
            Peach,
            PeachDark
        )
    }
}
