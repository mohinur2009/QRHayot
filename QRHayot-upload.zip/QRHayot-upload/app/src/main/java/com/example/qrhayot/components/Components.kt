package com.example.qrhayot.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.qrhayot.Lang
import com.example.qrhayot.R
import com.example.qrhayot.saveLanguage
import com.example.qrhayot.t
import com.example.qrhayot.ui.theme.*

// A round colored circle with an icon inside
@Composable
fun IconBubble(icon: Int, tint: Color, background: Color, size: Dp = 48.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(background),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(size / 2)
        )
    }
}

// A soft pastel card with rounded corners. Tapping it calls onClick.
@Composable
fun SoftCard(color: Color, onClick: () -> Unit, modifier: Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(color)
            .clickable { onClick() }
            .padding(18.dp)
    ) {
        content()
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = TextDark,
        modifier = Modifier.padding(top = 26.dp, bottom = 12.dp)
    )
}

// Round white back button with an arrow
@Composable
fun BackButton(onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(White)
            .border(1.dp, Line, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(R.drawable.ic_back), contentDescription = t("Orqaga", "Back"), tint = TextDark, modifier = Modifier.size(22.dp))
    }
}

// Top row of every inner screen: back button + title
@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        BackButton(onBack)
        Spacer(Modifier.width(14.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, color = TextDark)
    }
}

// Big teal button with an icon
@Composable
fun MainButton(text: String, icon: Int, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Teal),
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        Icon(painterResource(icon), contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

// White button with a thin border and an icon
@Composable
fun LightButton(text: String, icon: Int, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = White, contentColor = Teal),
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        Icon(painterResource(icon), contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

// A white text box with rounded corners
@Composable
fun InputField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    multiline: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text
) {
    var lines = 1
    if (multiline) {
        lines = 4
    }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { Text(hint, color = TextGrey) },
        singleLine = !multiline,
        minLines = lines,
        textStyle = MaterialTheme.typography.bodyLarge,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = White,
            unfocusedContainerColor = White,
            focusedBorderColor = Teal,
            unfocusedBorderColor = Line,
            focusedLabelColor = Teal,
            cursorColor = Teal
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

// A row of round options. The chosen one is filled with teal.
@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (option in options) {
            var background = White
            var textColor = TextDark
            if (option == selected) {
                background = Teal
                textColor = White
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(background)
                    .border(1.dp, Line, RoundedCornerShape(50))
                    .clickable { onSelect(option) }
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(option, style = MaterialTheme.typography.labelMedium, color = textColor)
            }
        }
    }
}

// Same layout for every form: top bar, colored header, fields, save button
@Composable
fun FormLayout(
    title: String,
    description: String,
    icon: Int,
    color: Color,
    iconColor: Color,
    onBack: () -> Unit,
    content: @Composable () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TopBar(title, onBack)

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(color)
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBubble(icon, iconColor, White, 52.dp)
            Spacer(Modifier.width(14.dp))
            Text(description, style = MaterialTheme.typography.bodyMedium, color = TextDark)
        }

        content()

        Spacer(Modifier.height(6.dp))
        Button(
            onClick = onBack,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Teal),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(t("Saqlash", "Save"), style = MaterialTheme.typography.labelLarge)
        }
    }
}

// Small grey heading inside forms
@Composable
fun FieldGroupTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = TextGrey, modifier = Modifier.padding(top = 4.dp))
}

// Shows "Kiritilmagan" / "Not added" when a value is empty
fun showValue(value: String): String {
    if (value.isBlank()) {
        return t("Kiritilmagan", "Not added")
    } else {
        return value
    }
}

// Small "UZ | EN" switch. Tapping changes the language of the whole app.
@Composable
fun LanguageSwitch() {
    val context = LocalContext.current
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(White)
            .border(1.dp, Line, RoundedCornerShape(50))
            .padding(4.dp)
    ) {
        LanguageOption("UZ", !Lang.english, onClick = {
            Lang.english = false
            saveLanguage(context)
        })
        LanguageOption("EN", Lang.english, onClick = {
            Lang.english = true
            saveLanguage(context)
        })
    }
}

@Composable
fun LanguageOption(text: String, selected: Boolean, onClick: () -> Unit) {
    var background = White
    var textColor = TextGrey
    if (selected) {
        background = Teal
        textColor = White
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = textColor)
    }
}

// A soft colored box with an "i" icon and a short message
@Composable
fun InfoBox(text: String, color: Color, iconColor: Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(color)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(R.drawable.ic_info), contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = TextDark)
    }
}
