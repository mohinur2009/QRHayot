package com.example.qrhayot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.qrhayot.R
import com.example.qrhayot.data.*
import com.example.qrhayot.t
import com.example.qrhayot.ui.components.*
import com.example.qrhayot.ui.theme.*

@Composable
fun PersonalScreen(profile: Profile, onBack: () -> Unit) {
    FormLayout(
        t("Shaxsiy", "Personal"),
        t("Sizga yordam berayotgan odam kimligingizni bilsin.", "Let the person helping you know who you are."),
        R.drawable.ic_person, Blue, Teal, onBack
    ) {
        InputField(t("Ism familiya", "Full name"), profile.name, { profile.name = it }, t("Masalan: Aziza Karimova", "e.g. Aziza Karimova"))
        InputField(t("Tug'ilgan yil", "Year of birth"), profile.birthYear, { profile.birthYear = it }, "2008", keyboard = KeyboardType.Number)
        InputField(t("Qaysi tillarda gaplashaman", "Languages I speak"), profile.languages, { profile.languages = it }, t("Masalan: o'zbek, rus, ingliz", "e.g. Uzbek, Russian, English"))
        InputField(
            t("Bilishlari kerak bo'lgan narsa", "Something they should know"),
            profile.notes,
            { profile.notes = it },
            t("Masalan: yaxshi eshitmayman", "e.g. I don't hear well"),
            multiline = true
        )
    }
}

@Composable
fun MedicalScreen(profile: Profile, onBack: () -> Unit) {
    FormLayout(
        t("Tibbiy", "Medical"),
        t("Shifokorlar va tez yordam uchun muhim ma'lumotlar.", "Important information for doctors and paramedics."),
        R.drawable.ic_medical, Pink, PinkDark, onBack
    ) {
        FieldGroupTitle(t("Qon guruhi", "Blood type"))
        ChipRow(BLOOD_TYPES, profile.bloodType, onSelect = {
            if (profile.bloodType == it) {
                profile.bloodType = ""   // tap again to remove
            } else {
                profile.bloodType = it
            }
        })
        InputField(t("Allergiyalar", "Allergies"), profile.allergies, { profile.allergies = it }, t("Masalan: penitsillin, yong'oq", "e.g. penicillin, nuts"))
        InputField(t("Doimiy ichadigan dorilar", "Medicines I take"), profile.medicines, { profile.medicines = it }, t("Masalan: insulin", "e.g. insulin"))
        InputField(
            t("Dorim qayerda turadi", "Where my medicine is"),
            profile.medicineLocation,
            { profile.medicineLocation = it },
            t("Masalan: sumkamning chap cho'ntagida", "e.g. left pocket of my bag")
        )
    }
}

@Composable
fun FirstAidScreen(profile: Profile, onBack: () -> Unit) {
    FormLayout(
        t("Birinchi yordam", "First aid"),
        t("Xuruj bo'lsa, atrofdagilar nima qilishi kerak.", "What people nearby should do in an attack."),
        R.drawable.ic_first_aid, Mint, MintDark, onBack
    ) {
        // 1. Ready templates
        FieldGroupTitle(t("Holatingizni tanlang, tayyor ko'rsatma qo'shiladi", "Choose your condition to add ready instructions"))
        ChipRow(conditionNames(), profile.condition, onSelect = {
            val index = conditionNames().indexOf(it)
            profile.condition = it
            profile.doSteps = doStepsFor(index)
            profile.dontSteps = dontStepsFor(index)
        })
        InputField(t("Holatim", "My condition"), profile.condition, { profile.condition = it }, t("Masalan: Epilepsiya", "e.g. Epilepsy"))
        InputField(t("Nima qilish kerak", "What to do"), profile.doSteps, { profile.doSteps = it }, "1. ...", multiline = true)
        InputField(t("Nima qilmaslik kerak", "What NOT to do"), profile.dontSteps, { profile.dontSteps = it }, "- ...", multiline = true)

        // 2. The person's own tips
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Peach)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painterResource(R.drawable.ic_bulb), contentDescription = null, tint = PeachDark, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(t("Mening maslahatlarim", "My own tips"), style = MaterialTheme.typography.titleSmall, color = TextDark)
                Text(
                    t("Faqat sizga yordam beradigan narsalarni yozing.", "Write what helps only you."),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGrey
                )
            }
        }
        InputField(
            t("Mening maslahatlarim", "My own tips"),
            profile.myTips,
            { profile.myTips = it },
            t(
                "Masalan: Menga shirin choy bering. Chiroqni o'chiring. Qo'limni ushlab turing.",
                "e.g. Give me sweet tea. Turn off bright lights. Hold my hand."
            ),
            multiline = true
        )

        InfoBox(
            t(
                "Bu umumiy birinchi yordam ko'rsatmalari. Shifokoringiz bilan tekshirib, o'zingizga moslang.",
                "These are general first aid steps. Check them with your doctor and adjust them for you."
            ),
            Lavender,
            LavenderDark
        )
    }
}

@Composable
fun ContactsScreen(profile: Profile, onBack: () -> Unit) {
    FormLayout(
        t("Yaqinlarim", "My contacts"),
        t("Favqulodda holatda kimga qo'ng'iroq qilinsin.", "Who should be called in an emergency."),
        R.drawable.ic_phone, Peach, PeachDark, onBack
    ) {
        FieldGroupTitle(t("1-kontakt", "Contact 1"))
        InputField(t("Kim?", "Who?"), profile.contact1Name, { profile.contact1Name = it }, t("Masalan: Onam", "e.g. Mom"))
        InputField(t("Telefon", "Phone"), profile.contact1Phone, { profile.contact1Phone = it }, "+998901234567", keyboard = KeyboardType.Phone)
        FieldGroupTitle(t("2-kontakt", "Contact 2"))
        InputField(t("Kim?", "Who?"), profile.contact2Name, { profile.contact2Name = it }, t("Masalan: Dadam", "e.g. Dad"))
        InputField(t("Telefon", "Phone"), profile.contact2Phone, { profile.contact2Phone = it }, "+998901234567", keyboard = KeyboardType.Phone)
        InfoBox(
            t("Bu raqamlarga SOS xabar ham yuboriladi.", "SOS messages are also sent to these numbers."),
            Blue,
            Teal
        )
    }
}
