package com.example.qrhayot.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

// Always light and calm. (No dynamic colors, so the pastel palette is never replaced by the phone's wallpaper colors.)
private val LightColors = lightColorScheme(
    primary = Teal,
    onPrimary = White,
    primaryContainer = Blue,
    onPrimaryContainer = TextDark,
    secondary = PinkDark,
    background = Background,
    onBackground = TextDark,
    surface = White,
    onSurface = TextDark,
    surfaceContainerHigh = White,
    surfaceContainerHighest = White,
    outline = Line
)

@Composable
fun QRHayotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = Typography,
        content = content
    )
}
