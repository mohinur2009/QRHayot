package com.example.qrhayot

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import com.example.qrhayot.data.Profile
import com.example.qrhayot.data.loadProfile
import com.example.qrhayot.data.saveProfile
import com.example.qrhayot.ui.theme.Background
import com.example.qrhayot.ui.theme.QRHayotTheme

class MainActivity : ComponentActivity() {

    private var profile = Profile()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Dark status bar icons on our light background
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        profile = loadProfile(this)
        loadLanguage(this)

        setContent {
            QRHayotTheme {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Background)
                        .systemBarsPadding()
                        .imePadding()
                ) {
                    AppNavigation(profile)
                }
            }
        }
    }

    // Save when the app goes to the background, so nothing is lost
    override fun onPause() {
        super.onPause()
        saveProfile(this, profile)
    }
}
