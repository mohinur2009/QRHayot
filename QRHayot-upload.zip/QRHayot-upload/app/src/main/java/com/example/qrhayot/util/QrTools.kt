package com.example.qrhayot.util

import android.Manifest
import android.app.WallpaperManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.location.LocationManager
import android.media.ToneGenerator
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.qrhayot.t
import com.google.zxing.*
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.example.qrhayot.data.Profile
import java.io.*

// The text inside the QR code. Labels are in Uzbek and English.
// The most urgent things come first, because a stranger in an emergency reads from the top.
fun buildQrText(p: Profile): String {
    var qr = "QR HAYOT - FAVQULODDA / EMERGENCY\n"
    qr = qr + "Tez yordam / Ambulance: 103\n\n"

    var name = p.name.trim()
    if (p.birthYear.isNotBlank()) {
        name = name + " (" + p.birthYear.trim() + ")"
    }
    qr = addLine(qr, "ISM / NAME", name)
    qr = addLine(qr, "TILLAR / LANGUAGES", p.languages)
    qr = addLine(qr, "HOLATI / CONDITION", p.condition)
    qr = addLine(qr, "DORISI QAYERDA / MEDICINE IS", p.medicineLocation)

    if (p.doSteps.isNotBlank()) {
        qr = qr + "\nNIMA QILISH KERAK / WHAT TO DO:\n" + p.doSteps.trim() + "\n"
    } else {
        qr = qr + "\nHushsiz va nafas olmasa: 103, ko'krak markazini bosing.\nUnconscious and not breathing: call 103, push the center of the chest.\n"
    }
    if (p.dontSteps.isNotBlank()) {
        qr = qr + "\nQILMANG / DO NOT:\n" + p.dontSteps.trim() + "\n"
    }
    if (p.myTips.isNotBlank()) {
        qr = qr + "\nMENING MASLAHATLARIM / MY TIPS:\n" + p.myTips.trim() + "\n"
    }

    if (p.contact1Phone.isNotBlank() || p.contact2Phone.isNotBlank()) {
        qr = qr + "\nQO'NG'IROQ QILING / CALL:\n"
        qr = addContact(qr, p.contact1Name, p.contact1Phone)
        qr = addContact(qr, p.contact2Name, p.contact2Phone)
    }

    qr = qr + "\n"
    qr = addLine(qr, "QON GURUHI / BLOOD", p.bloodType)
    qr = addLine(qr, "ALLERGIYA / ALLERGY", p.allergies)
    qr = addLine(qr, "DORILAR / MEDICINES", p.medicines)
    qr = addLine(qr, "IZOH / NOTE", p.notes)
    qr = addLine(qr, "YANGILANGAN / UPDATED", p.updated)
    return qr.trim()
}

fun addLine(text: String, label: String, value: String): String {
    if (value.isBlank()) {
        return text
    } else {
        return text + label + ": " + value.trim() + "\n"
    }
}

fun addContact(text: String, name: String, phone: String): String {
    if (phone.isBlank()) {
        return text
    } else {
        return text + name.trim() + " " + phone.trim() + "\n"
    }
}

// Makes a black and white QR picture. Returns null if the text is too long.
fun makeQr(text: String): Bitmap? {
    try {
        val hints = HashMap<EncodeHintType, Any>()
        hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
        hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.M
        hints[EncodeHintType.MARGIN] = 2

        val size = 800
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) {
            for (y in 0 until size) {
                if (matrix.get(x, y)) {
                    bitmap.setPixel(x, y, Color.BLACK)
                } else {
                    bitmap.setPixel(x, y, Color.WHITE)
                }
            }
        }
        return bitmap
    } catch (e: Exception) {
        return null
    }
}

// A clean picture for the lock screen and for sharing:
// soft blue background, a title, and the QR on a white rounded card.
fun makePoster(qr: Bitmap, width: Int, height: Int): Bitmap {
    val poster = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(poster)
    canvas.drawColor(Color.rgb(234, 245, 249))

    val cardSize = width * 0.72f
    val left = (width - cardSize) / 2f
    val top = height * 0.40f   // low on the screen, so the clock does not cover it
    val bottomSpace = width * 0.12f

    // White card with soft rounded corners
    val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    cardPaint.color = Color.WHITE
    val card = RectF(left, top, left + cardSize, top + cardSize + bottomSpace)
    canvas.drawRoundRect(card, width * 0.06f, width * 0.06f, cardPaint)

    // QR inside the card
    val padding = width * 0.05f
    val qrSize = (cardSize - padding * 2).toInt()
    val small = Bitmap.createScaledBitmap(qr, qrSize, qrSize, false)
    canvas.drawBitmap(small, left + padding, top + padding, null)

    // "Ambulance 103" at the bottom of the card
    val call = Paint(Paint.ANTI_ALIAS_FLAG)
    call.color = Color.rgb(46, 125, 140)
    call.textAlign = Paint.Align.CENTER
    call.typeface = Typeface.DEFAULT_BOLD
    call.textSize = width * 0.042f
    canvas.drawText("Tez yordam / Ambulance: 103", width / 2f, top + cardSize + bottomSpace * 0.55f, call)

    // Title and subtitle above the card
    val title = Paint(Paint.ANTI_ALIAS_FLAG)
    title.color = Color.rgb(192, 86, 106)
    title.textAlign = Paint.Align.CENTER
    title.typeface = Typeface.DEFAULT_BOLD
    title.textSize = width * 0.058f
    canvas.drawText("FAVQULODDA / EMERGENCY", width / 2f, top - width * 0.13f, title)

    val subtitle = Paint(Paint.ANTI_ALIAS_FLAG)
    subtitle.color = Color.rgb(107, 119, 128)
    subtitle.textAlign = Paint.Align.CENTER
    subtitle.textSize = width * 0.04f
    canvas.drawText("Skanerlang / Scan me", width / 2f, top - width * 0.06f, subtitle)

    return poster
}

// Opens the share menu (Telegram, Gallery, Files...)
fun shareImage(context: Context, bitmap: Bitmap) {
    val folder = File(context.cacheDir, "images")
    folder.mkdirs()
    val file = File(folder, "qr_hayot.png")
    val stream = FileOutputStream(file)
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
    stream.close()

    val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND)
    intent.type = "image/png"
    intent.putExtra(Intent.EXTRA_STREAM, uri)
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(intent, "QR kodni ulashish"))
}

// Puts the picture on the lock screen. Returns false if the phone does not allow it.
fun setLockScreen(context: Context, bitmap: Bitmap): Boolean {
    try {
        WallpaperManager.getInstance(context).setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
        return true
    } catch (e: Exception) {
        return false
    }
}

// Opens the phone dialer with the number already typed in.
fun callNumber(context: Context, number: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number))
    context.startActivity(intent)
}

// Opens a map app and searches nearby, e.g. openMap(context, "hospital")
fun openMap(context: Context, search: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(search)))
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, t("Xarita ilovasi topilmadi", "No map app found"), Toast.LENGTH_LONG).show()
    }
}

// A link to the phone's last known location, or "" if it is not available
fun lastLocationLink(context: Context): String {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
    if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) {
        return ""
    }
    try {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        if (location == null) {
            location = manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        }
        if (location == null) {
            return ""
        } else {
            return "https://maps.google.com/?q=" + location.latitude + "," + location.longitude
        }
    } catch (e: Exception) {
        return ""
    }
}

// Opens the SMS app with an SOS message (and location) to both contacts. The user presses "Send".
fun sendSos(context: Context, p: Profile) {
    var numbers = p.contact1Phone.trim()
    if (p.contact2Phone.isNotBlank()) {
        if (numbers.isNotEmpty()) {
            numbers = numbers + ";"
        }
        numbers = numbers + p.contact2Phone.trim()
    }

    var message = t("SOS! Menga yordam kerak. ", "SOS! I need help. ") + p.name.trim()
    val link = lastLocationLink(context)
    if (link.isNotEmpty()) {
        message = message + "\n" + t("Joylashuvim: ", "My location: ") + link
    }

    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + numbers))
    intent.putExtra("sms_body", message)
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, t("SMS ilovasi topilmadi", "No SMS app found"), Toast.LENGTH_LONG).show()
    }
}

// A sound maker for the CPR beat and the siren. Returns null if the phone has no sound.
fun makeTone(stream: Int): ToneGenerator? {
    try {
        return ToneGenerator(stream, 100)
    } catch (e: Exception) {
        return null
    }
}

