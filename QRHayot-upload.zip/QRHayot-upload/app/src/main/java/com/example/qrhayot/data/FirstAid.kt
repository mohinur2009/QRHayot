package com.example.qrhayot.data

import com.example.qrhayot.Lang
import com.example.qrhayot.t


val CONDITIONS_UZ = listOf("Epilepsiya", "Qandli diabet", "Astma", "Kuchli allergiya", "Yurak kasalligi", "Hushdan ketish", "Autizm", "Boshqa")
val CONDITIONS_EN = listOf("Epilepsy", "Diabetes", "Asthma", "Severe allergy", "Heart condition", "Fainting", "Autism", "Other")

val BLOOD_TYPES = listOf(
    "O(I) Rh+", "O(I) Rh-", "A(II) Rh+", "A(II) Rh-",
    "B(III) Rh+", "B(III) Rh-", "AB(IV) Rh+", "AB(IV) Rh-"
)


fun conditionNames(): List<String> {
    if (Lang.english) {
        return CONDITIONS_EN
    } else {
        return CONDITIONS_UZ
    }
}


fun doStepsFor(index: Int): String {
    if (index == 0) {
        return t(
            "1. Vaqtni belgilang. Ko'pincha 2 daqiqada to'xtaydi.\n" +
                    "2. Atrofdagi qattiq va o'tkir narsalarni olib qo'ying.\n" +
                    "3. Boshi ostiga yumshoq narsa qo'ying.\n" +
                    "4. Titrash to'xtagach, yonboshiga yotqizing.\n" +
                    "5. 5 daqiqadan uzoq davom etsa, yana boshlansa yoki o'ziga kelmasa, 103 ga qo'ng'iroq qiling.",
            "1. Note the time. Most seizures stop within 2 minutes.\n" +
                    "2. Move hard and sharp objects away.\n" +
                    "3. Put something soft under the head.\n" +
                    "4. When the shaking stops, turn them on their side.\n" +
                    "5. Call 103 if it lasts over 5 minutes, starts again, or they don't wake up."
        )
    } else if (index == 1) {
        return t(
            "1. Hushida bo'lsa va yuta olsa: shirin sharbat yoki 3-4 bo'lak qand bering.\n" +
                    "2. 15 daqiqa kuting. Yaxshilanmasa, yana bir marta bering.\n" +
                    "3. O'ziga kelgach, non yoki pechenye bering.\n" +
                    "4. Hushidan ketsa: yonboshiga yotqizing va 103 ga qo'ng'iroq qiling.",
            "1. If awake and able to swallow: give sweet juice or 3-4 sugar cubes.\n" +
                    "2. Wait 15 minutes. If not better, give sugar again.\n" +
                    "3. When better, give bread or biscuits.\n" +
                    "4. If unconscious: turn them on their side and call 103."
        )
    } else if (index == 2) {
        return t(
            "1. Tik o'tirishiga yordam bering, tinchlantiring.\n" +
                    "2. Ko'k ingalyatorini bering: har 30-60 soniyada 1 marta purkasin, 10 martagacha.\n" +
                    "3. Yaxshilanmasa yoki yomonlashsa, darhol 103 ga qo'ng'iroq qiling.",
            "1. Help them sit upright and stay calm.\n" +
                    "2. Give their blue inhaler: 1 puff every 30-60 seconds, up to 10 puffs.\n" +
                    "3. Call 103 right away if they are not better or getting worse."
        )
    } else if (index == 3) {
        return t(
            "1. Darhol 103 ga qo'ng'iroq qiling.\n" +
                    "2. Adrenalin avto-injektori (EpiPen) bo'lsa, sonning tashqi tomoniga qilishga yordam bering.\n" +
                    "3. Yotqizib, oyoqlarini ko'taring. Nafas olishi qiyin bo'lsa, o'tqazing.\n" +
                    "4. 5 daqiqada yaxshilanmasa va ikkinchi injektor bo'lsa, uni ham ishlating.",
            "1. Call 103 right away.\n" +
                    "2. If they have an adrenaline auto-injector (EpiPen), help use it on the outer thigh.\n" +
                    "3. Lie them down and raise their legs. If breathing is hard, let them sit up.\n" +
                    "4. If not better after 5 minutes and there is a second injector, use it."
        )
    } else if (index == 4) {
        return t(
            "1. Darhol 103 ga qo'ng'iroq qiling.\n" +
                    "2. O'tqazing, tinchlantiring, qattiq kiyimini bo'shating.\n" +
                    "3. Shifokor yozib bergan yurak dorisi yonida bo'lsa, ichishiga yordam bering.\n" +
                    "4. Hushidan ketib, normal nafas olmasa: ko'krak markazini qattiq va tez bosing (daqiqasiga 100-120 marta).",
            "1. Call 103 right away.\n" +
                    "2. Sit them down, keep them calm, loosen tight clothes.\n" +
                    "3. If they have their own prescribed heart medicine, help them take it.\n" +
                    "4. If they collapse and are not breathing normally: push hard and fast in the center of the chest (100-120 times a minute)."
        )
    } else if (index == 5) {
        return t(
            "1. Chalqanchasiga yotqizing va oyoqlarini ko'taring (masalan, sumka ustiga).\n" +
                    "2. Qattiq kiyimini bo'shating, toza havo bering.\n" +
                    "3. O'ziga kelgach, sekin o'tirishiga yordam bering.\n" +
                    "4. 1 daqiqada o'ziga kelmasa: yonboshiga yotqizing va 103 ga qo'ng'iroq qiling.",
            "1. Lay them on their back and raise their legs (for example, on a bag).\n" +
                    "2. Loosen tight clothes and give them fresh air.\n" +
                    "3. When they wake up, help them sit up slowly.\n" +
                    "4. If they don't wake up within 1 minute: turn them on their side and call 103."
        )
    } else if (index == 6) {
        return t(
            "1. Xotirjam bo'ling. Bitta odam yordam bersin, boshqalar uzoqlashsin.\n" +
                    "2. Shovqin, yorug'lik va olomonni kamaytiring.\n" +
                    "3. Kam, sekin va mehribon gapiring. Javob berishga vaqt bering.\n" +
                    "4. Xohlasa, tinchroq joyga o'tishiga yordam bering.\n" +
                    "5. Yaqinlarimga qo'ng'iroq qiling (raqamlar pastda).",
            "1. Stay calm. Let one person help and ask others to step back.\n" +
                    "2. Reduce noise, bright light and crowds.\n" +
                    "3. Speak little, slowly and kindly. Give time to answer.\n" +
                    "4. If they want, help them move to a quieter place.\n" +
                    "5. Call my family (numbers below)."
        )
    } else {
        return t("1. 103 ga qo'ng'iroq qiling.\n2. \n3. ", "1. Call 103.\n2. \n3. ")
    }
}

fun dontStepsFor(index: Int): String {
    if (index == 0) {
        return t(
            "- Og'ziga hech narsa solmang.\n- Ushlab, majburan to'xtatishga urinmang.\n- To'liq o'ziga kelmaguncha suv yoki ovqat bermang.",
            "- Do not put anything in their mouth.\n- Do not hold them down.\n- No food or water until fully awake."
        )
    } else if (index == 1) {
        return t(
            "- Hushsiz odamning og'ziga ovqat yoki suv solmang.\n- Yolg'iz qoldirmang.",
            "- Do not put food or drink in the mouth of an unconscious person.\n- Do not leave them alone."
        )
    } else if (index == 2) {
        return t(
            "- Yotqizmang.\n- Yolg'iz qoldirmang.",
            "- Do not lay them down.\n- Do not leave them alone."
        )
    } else if (index == 3) {
        return t(
            "- To'satdan turg'izmang va yurgizmang.\n- Allergiya bergan narsani boshqa bermang.",
            "- Do not let them stand up or walk suddenly.\n- Do not give the allergy trigger again."
        )
    } else if (index == 4) {
        return t(
            "- Yurgizmang, o'zi mashina haydamasin.\n- Yolg'iz qoldirmang.",
            "- Do not let them walk or drive.\n- Do not leave them alone."
        )
    } else if (index == 5) {
        return t(
            "- To'liq o'ziga kelmaguncha ovqat yoki suv bermang.\n- Tez turg'izmang.",
            "- No food or water until fully awake.\n- Do not make them stand up quickly."
        )
    } else if (index == 6) {
        return t(
            "- So'ramasdan tegmang va ushlamang.\n- Baqirmang, ko'p savol bermang.\n- Tikilib qaramang, videoga olmang.",
            "- Do not touch or hold them without asking.\n- Do not shout or ask many questions.\n- Do not stare or film."
        )
    } else {
        return "- "
    }
}
